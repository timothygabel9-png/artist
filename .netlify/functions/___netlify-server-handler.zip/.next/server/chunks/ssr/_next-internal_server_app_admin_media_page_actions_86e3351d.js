module.exports=[84527,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_media_page_actions_86e3351d.js.map