module.exports=[51698,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_portfolio_page_actions_a4a70c2b.js.map