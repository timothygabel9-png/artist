module.exports=[1408,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portfolio_%5Bid%5D_page_actions_9c2365c8.js.map